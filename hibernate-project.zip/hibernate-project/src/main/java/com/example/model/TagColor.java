package com.example.model;

public enum TagColor {
    BLUE, YELLOW, GREEN, RED
}
